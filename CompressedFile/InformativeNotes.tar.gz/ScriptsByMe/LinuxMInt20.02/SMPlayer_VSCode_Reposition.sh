#!/bin/bash
wmctrl -r SMPlayer -b toggle,maximized_vert,maximized_horz
wmctrl -r SMPlayer -b remove,maximized_vert,maximized_horz
wmctrl -r SMPlayer -e 0,0,360,1366,743
wmctrl -r Code -b toggle,maximized_vert,maximized_horz
wmctrl -r Code -b remove,maximized_vert,maximized_horz
wmctrl -r Code -e 0,1366,48,1920,1015
wmctrl -a Code
exit 0
