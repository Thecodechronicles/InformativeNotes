#!/bin/bash

firefox & code & vlc /home/ankit/Desktop/LinkToUdemy-JavaScriptUnderstandingTheWeirdParts/JsUnderstandingWeirdParts.xspf & gedit /home/ankit/InformativeNotes/DevKeyBoardShortcuts /home/ankit/InformativeNotes/CommandsToRemember & nautilus /home/ankit/Desktop/LinkToUdemy-JavaScriptUnderstandingTheWeirdParts &
sleep 5
wmctrl -r DevKeyBoardShortcuts -e 0,1602,378,591,606
wmctrl -r LinkToUdemy-JavaScriptUnderstandingTheWeirdParts -e 0,0,54,1366,741
wmctrl -r Code -e 0,1,102,1366,704
wmctrl -r firefox -e 0,1,28,1366,741
sleep 2
wmctrl -a LinkToUdemy-JavaScriptUnderstandingTheWeirdParts
wmctrl -a DevKeyBoardShortcuts
sleep 1
wmctrl -a firefox
sleep 1
wmctrl -a code
sleep 2
wmctrl -r VLC -e 0,1,102,1366,704
wmctrl -a vlc
exit 0

