#!/bin/bash

firefox & 
code & 
vlc /home/ankit/Desktop/LinktoU_d_e_m_yProjectsinAngularJS-Learnbybuilding10Projects/Playlist.xspf &
gedit /home/ankit/InformativeNotes/DevKeyBoardShortcuts /home/ankit/InformativeNotes/CommandsToRemember & 
nautilus /home/ankit/Desktop/LinktoU_d_e_m_yProjectsinAngularJS-Learnbybuilding10Projects &
sleep 5
a=0 b=1 c=2 d=3 e=4 
l='false' m='false' n='false' o='false' p='false'
boolArr=('false' 'false' 'false' 'false' 'false')
loopbreak= 'false'
i=0
while [ $i -lt 5  ]
do
 i=$(( $i+1 ))
 sleep 1
 if [[ ${boolArr[i]} == 'false' ]]
 then
  loopbreak='true'
  if [[ "$(xdotool search --onlyvisible -class nautilus getwindowname)" == *"LinktoU_d_e_m_yProjectsinAngularJS-Learnbybuilding10Projects"* ]] && [ "$l" == "false" ]
  then
   $(wmctrl -r LinktoU_d_e_m_yProjectsinAngularJS-Learnbybuilding10Projects -e 0,3840,678,1366,741)
   l='true' 
   boolArr[a]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class gedit getwindowname)" == *"DevKeyBoardShortcuts"* ]] && [ "$m" == "false" ]
  then
   $(wmctrl -r DevKeyBoardShortcuts -e 0,5286,882,669,668)
   m='true'
   boolArr[b]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class code getwindowname)" == *"Code"* ]] && [ "$n" == 'false' ]
  then
   $(wmctrl -r Code -e 0,1,1,1920,1080)
   n='true'
   boolArr[c]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class vlc getwindowname)" == *"VLC"* ]] && [ "$o" == 'false' ]
  then
   $(wmctrl -r VLC -e 0,1920,312,1366,768)
   o='true'
   boolArr[d]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class firefox getwindowname)" == *"Firefox"* ]] && [ "$p" == 'false' ]
  then
   $(wmctrl -r firefox -e 0,1,1,1920,1080)
   p='true'
   boolArr[e]='true'
  fi
 fi
 if [ "$i" -eq "4" ] && [[ "$loopbreak" == 'true' ]]
  then
   loopbreak='false'
   i=0;
  fi
done
sleep 2
wmctrl -a LinkToUdemy-JavaScriptUnderstandingTheWeirdParts
wmctrl -a DevKeyBoardShortcuts
sleep 2
wmctrl -a code
sleep 2
wmctrl -a vlc
exit 0
