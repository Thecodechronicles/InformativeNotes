#!/bin/bash

firefox & 
code & 
vlc /home/ankit/Desktop/LinkToUdemy-JavaScriptUnderstandingTheWeirdParts/JsUnderstandingWeirdParts.xspf &
gedit /home/ankit/InformativeNotes/DevKeyBoardShortcuts /home/ankit/InformativeNotes/CommandsToRemember & 
nautilus /home/ankit/Desktop/LinkToUdemy-JavaScriptUnderstandingTheWeirdParts &
sleep 5

#while(boolArr[i]=='false'){
#if(xdotool search --onlyvisible -class nautilus #getwindowname == 'LinkToUdemy-#JavaScriptUnderstandingTheWeirdParts')
#{
#echo 'Hey ! its wonderful !!'
#a = true;
#}
#
#sleep 2
#}

a=0 b=1 c=2 d=3 e=4 
l='false' m='false' n='false' o='false' p='false'
echo 'Hi Everyone !'
boolArr=('false' 'false' 'false' 'false' 'false')
loopbreak= 'false'
#for i in  {0..4..1}
#for(i=0;i<boolArr.length;i++)
#{
i=0
while [ $i -lt 5  ]
do
 i=$(( $i+1 ))
 sleep 1
 echo ${boolArr[*]}
 echo 'Hi all !'
 echo $i
 if [[ ${boolArr[i]} == 'false' ]]
 then
  loopbreak='true'
  echo 'Hmm ! Ok'
  if [[ "$(xdotool search --onlyvisible -class nautilus getwindowname)" == *"LinkToUdemy-JavaScriptUnderstandingTheWeirdParts"* ]] && [ "$l" == "false" ]
  then
   echo 'Wah !'
   $(wmctrl -r LinkToUdemy-JavaScriptUnderstandingTheWeirdParts -e 0,3840,678,1366,741)
   l='true' 
   boolArr[a]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class gedit getwindowname)" == *"DevKeyBoardShortcuts"* ]] && [ "$m" == "false" ]
  then
   echo 'aha !'
   $(wmctrl -r DevKeyBoardShortcuts -e 0,5442,1006,591,606)
   m='true'
   boolArr[b]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class code getwindowname)" == *"Code"* ]] && [ "$n" == 'false' ]
  then
   echo 'Wah wah !'
   $(wmctrl -r Code -e 0,1921,414,1366,704)
   n='true'
   boolArr[c]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class vlc getwindowname)" == *"VLC"* ]] && [ "$o" == 'false' ]
  then
   echo 'Wah kya baat !'
   $(wmctrl -r VLC -e 0,1,75,1920,1043)
   o='true'
   boolArr[d]='true'
  fi
  if [[ "$(xdotool search --onlyvisible -class firefox getwindowname)" == *"Firefox"* ]] && [ "$p" == 'false' ]
  then
   echo 'Wah taj!'
   $(wmctrl -r firefox -e 0,1,1,1920,1080)
   p='true'
   boolArr[e]='true'
  fi
 fi
 if [ "$i" -eq "4" ] && [[ "$loopbreak" == 'true' ]]
  then
   loopbreak='false'
   echo 'Wah be !'
   i=0;
   echo $i
  fi
done
#echo ${boolArr[*]}

#wmctrl -r LinkToUdemy-JavaScriptUnderstandingTheWeirdParts -e 0,3840,678,1366,741
#wmctrl -r DevKeyBoardShortcuts -e 0,5442,1006,591,606
#wmctrl -r Code -e 0,1921,414,1366,704
#wmctrl -r VLC -e 0,1,75,1920,1043
#wmctrl -r firefox -e 0,1,1,1920,1080
sleep 2
wmctrl -a LinkToUdemy-JavaScriptUnderstandingTheWeirdParts
wmctrl -a DevKeyBoardShortcuts
sleep 2
wmctrl -a code
sleep 2
wmctrl -a vlc
exit 0
